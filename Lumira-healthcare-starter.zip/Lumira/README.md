# Lumira

**Healthcare Door To Door**  
*One Step Towards Humanity*

A starter front-end for the Lumira healthcare platform.

## 7 portals
1. Doctor
2. Patient
3. Lab
4. Pharmacy
5. Ambulance
6. SOS Service
7. Nursing Home

## Run
Open `index.html` in a browser.

## GitHub Pages
Upload `index.html`, `style.css`, and `script.js` to your repository and configure Pages to deploy from the branch containing these files.

This starter is a front-end prototype. Authentication, databases, payments, medical records, and emergency integrations require a secure backend and appropriate compliance/security work.
