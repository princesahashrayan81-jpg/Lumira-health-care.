# Lumira

**Healthcare Door to Door**

Lumira is a healthcare ecosystem concept designed to connect seven portals:

1. Doctor
2. Patient
3. Lab
4. Pharmacy
5. Ambulance
6. SOS Service
7. Nursing Home

## Current build

This repository contains the first responsive frontend MVP:
- Portal selection UI
- Patient entry flow
- Emergency SOS entry flow
- Responsive mobile/desktop design
- Demo-mode interactions

## Run locally

No build system is required for this first MVP.

Open `index.html` in a browser.

## Next development phases

- Authentication and role-based access
- Patient profile and appointments
- Doctor consultation dashboard
- Lab booking and reports
- Pharmacy ordering
- Ambulance dispatch workflow
- SOS emergency workflow
- Nursing-home/facility management
- Backend API + database
- Notifications
- Security, privacy and audit logging

> This is a prototype and not yet a production healthcare application. Real patient data should not be used in this demo.
