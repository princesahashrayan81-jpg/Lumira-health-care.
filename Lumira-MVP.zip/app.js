const portals = [
  {name:"Doctor", icon:"🩺", text:"Appointments, consultations and clinical workspace."},
  {name:"Patient", icon:"🧑‍⚕️", text:"Find care, manage appointments and access your health journey."},
  {name:"Lab", icon:"🧪", text:"Diagnostic bookings, reports and lab workflow."},
  {name:"Pharmacy", icon:"💊", text:"Medicine discovery, orders and pharmacy services."},
  {name:"Ambulance", icon:"🚑", text:"Request and coordinate emergency transport."},
  {name:"SOS Service", icon:"🆘", text:"Emergency assistance and rapid-response workflow."},
  {name:"Nursing Home", icon:"🏥", text:"Care-facility services, beds and patient coordination."}
];

const grid = document.getElementById("portalGrid");
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");
const modalEyebrow = document.getElementById("modalEyebrow");
const demoInput = document.getElementById("demoInput");

function openPortal(portal){
  modalEyebrow.textContent = `${portal.name.toUpperCase()} PORTAL`;
  modalTitle.textContent = `Enter ${portal.name}`;
  modalText.textContent = portal.text;
  demoInput.placeholder = portal.name === "Patient" ? "Patient name or ID" : `${portal.name} ID`;
  modal.classList.remove("hidden");
  demoInput.focus();
}

function closeModal(){ modal.classList.add("hidden"); }

portals.forEach((portal) => {
  const card = document.createElement("article");
  card.className = "portal";
  card.innerHTML = `
    <div>
      <div class="portal-icon">${portal.icon}</div>
      <h3>${portal.name}</h3>
      <p>${portal.text}</p>
    </div>
    <button type="button">Open portal →</button>
  `;
  card.querySelector("button").addEventListener("click", () => openPortal(portal));
  grid.appendChild(card);
});

document.getElementById("patientBtn").addEventListener("click", () => openPortal(portals[1]));
document.getElementById("sosBtn").addEventListener("click", () => openPortal(portals[5]));
document.getElementById("aboutBtn").addEventListener("click", () => {
  modalEyebrow.textContent = "ABOUT LUMIRA";
  modalTitle.textContent = "Healthcare Door to Door";
  modalText.textContent = "Lumira is a healthcare ecosystem concept connecting patients and healthcare providers through specialised portals. This build is an early frontend MVP.";
  demoInput.value = "";
  demoInput.placeholder = "Demo mode";
  modal.classList.remove("hidden");
});
document.querySelectorAll("[data-close]").forEach(el => el.addEventListener("click", closeModal));
document.getElementById("enterBtn").addEventListener("click", () => {
  const value = demoInput.value.trim() || "Demo user";
  alert(`Welcome, ${value}! The ${modalEyebrow.textContent.replace(" PORTAL","")} workflow is ready for the next development phase.`);
  closeModal();
});
document.addEventListener("keydown", e => { if(e.key === "Escape") closeModal(); });
